---
weight: 3000
title: "Fonctionnalités"
description: "Descriptions et exemples des fonctionnalités du thème."
titleIcon: "fa-solid fa-cubes"
categories: ["Fonctionnalités"]
tags: ["Gestion du contenu"]
---

---

{{< treeview
  display="tree"
/>}}
