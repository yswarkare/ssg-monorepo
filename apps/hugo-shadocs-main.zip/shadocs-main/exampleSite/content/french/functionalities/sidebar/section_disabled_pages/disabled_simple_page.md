---
weight: 1000
title: "Page simple désactivée"
description: "Menu latéral: Page simple désactivée"
categories: ["Fonctionnalités"]
sidebarDisabled: true
---

# Page simple désactivée manuellement
---
