---
weight: 2000
title: "Page simple 2"
description: "Menu latéral: Page simple 2"
categories: ["Fonctionnalités"]
---
