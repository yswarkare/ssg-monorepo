---
weight: 3000
title: "Simple page 3"
description: "Sidebar: Simple page 3"
categories: ["Functionalities"]
---
