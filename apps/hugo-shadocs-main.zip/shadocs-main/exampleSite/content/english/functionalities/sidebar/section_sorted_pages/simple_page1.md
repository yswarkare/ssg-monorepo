---
weight: 1000
title: "Simple page 1"
description: "Sidebar: Simple page 1"
categories: ["Functionalities"]
---
