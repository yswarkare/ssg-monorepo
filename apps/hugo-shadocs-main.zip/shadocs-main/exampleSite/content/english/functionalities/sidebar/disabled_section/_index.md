---
weight: 3000
title: "Disabled section"
description: "Sidebar: Disabled section"
categories: ["Functionalities"]
---
