# Hello, World!
---
*Je suis* **un template** ***réutilisable*** à inclure dans le contenu d'une page.
