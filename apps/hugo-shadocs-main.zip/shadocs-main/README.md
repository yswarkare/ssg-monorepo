# Shadocs theme for Hugo

![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/jgazeau/shadocs/hugo.yml?branch=main&style=for-the-badge&logo=githubpages&logoSize=auto&label=Documentation%20Website&labelColor=steelblue&link=https%3A%2F%2Fjgazeau.github.io%2Fshadocs%2F)
![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/jgazeau/shadocs/branches.yml?branch=main&style=for-the-badge&logo=githubactions&logoColor=white&logoSize=auto)
![GitHub Tag](https://img.shields.io/github/v/tag/jgazeau/shadocs?sort=semver&style=for-the-badge&link=https%3A%2F%2Fgithub.com%2Fjgazeau%2Fshadocs%2Freleases)
![GitHub License](https://img.shields.io/github/license/jgazeau/shadocs?style=for-the-badge&logo=github)

## Documentation

To get all the needed information about the theme, visit the [Shadocs documentation website](https://jgazeau.github.io/shadocs/) which is built on it.
