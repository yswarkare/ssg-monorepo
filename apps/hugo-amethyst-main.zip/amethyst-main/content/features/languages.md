---
title: "Chinese, Japanese, Korean Support (测试)"
---

## Chinese, Japanese, Korean Support
几乎在我们意识到之前，我们已经离开了地面。

우리가 그것을 알기도 전에 우리는 땅을 떠났습니다.

私たちがそれを知るほぼ前に、私たちは地面を離れていました。

## RTL
More information on configuring RTL languages like Arabic in the [config](setup/config.md) page.
