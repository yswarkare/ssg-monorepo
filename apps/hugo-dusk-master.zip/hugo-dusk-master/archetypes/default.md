---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
tags:
  - x
  - y
categories:
  - x
  - y
draft: true
---
