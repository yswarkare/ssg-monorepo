---
title: "Getting Started"
date: 2017-10-17T15:26:15Z
lastmod: 2018-12-08T15:26:15Z
publishdate: 2018-11-23T15:26:15Z
draft: false
weight: 9

description: Text about this post
images:
- images/pexels-photo-196666.jpeg
---

## [Installation](./installation)

Download Hugo theme, configure, preview site ...

## [Configuration](./configuration)

You may specify options in hugo.toml (or hugo.yaml/hugo.json) of your site to make use of this theme's features.

## [Screenshot](./screenshot)
