+++
title = "Shortcodes"
description = ""
weight = 3
+++

{{< lead >}}
Shortcodes are a great way to add some more advanced elements to your page. Code highlighting, a 'lead' style paragraph, images, videos, and more.
{{< /lead >}}

{{< childpages >}}